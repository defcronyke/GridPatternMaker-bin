GridPatternMaker
================

A maker for grid patterns. May be useful for knitting designs and other.

Usage: gridpatternmaker [gpm_file] | [cols rows]

Works on 64-bit Linux and Windows. See files LICENSE and INSTALL for more info.
